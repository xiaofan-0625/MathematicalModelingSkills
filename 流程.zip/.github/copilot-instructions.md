# Mathematical modeling repository instructions

Read and follow `/SKILL.md` for the complete platform-neutral workflow.

Preserve original files in `/题目` and `/数据`. Put generated analysis and code in `/求解`, and paper artifacts in `/论文`. Use references progressively rather than loading `/references` wholesale. Never invent data, citations, execution results, or validation evidence.
