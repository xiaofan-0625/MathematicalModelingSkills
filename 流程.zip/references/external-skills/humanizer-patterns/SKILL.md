---
name: humanizer-patterns
description: Compatibility alias for auditing prose against recurring AI-writing patterns before controlled academic revision.
---

# Humanizer Patterns Compatibility Entry

Read and follow `../../../skills/academic-humanization/SKILL.md`. Report exact evidence for each flagged pattern.
