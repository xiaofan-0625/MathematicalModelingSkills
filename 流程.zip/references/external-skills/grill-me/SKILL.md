---
name: grill-me
description: Compatibility alias for interrogating a model or plan one decisive question at a time until material decision branches are resolved.
---

# Grill Me Compatibility Entry

Read and follow `../../../skills/model-deliberation/SKILL.md` using Interview mode.
