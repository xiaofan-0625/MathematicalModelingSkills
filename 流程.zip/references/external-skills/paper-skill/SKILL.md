---
name: paper-skill
description: Compatibility alias for end-to-end evidence-grounded manuscript planning, writing, citation checking, revision, and submission review.
---

# Paper Skill Compatibility Entry

Read and follow `../../../skills/academic-writing/SKILL.md`.
