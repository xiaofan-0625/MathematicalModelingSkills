---
name: matplotlib-consistency
description: Compatibility alias for consistent, correct Matplotlib styling, APIs, sizing, layout, and export across scientific figures.
---

# Matplotlib Consistency Compatibility Entry

Read and follow `../../../skills/scientific-visualization/SKILL.md`. Reuse retained code references in this directory when version-specific behavior matters.
