---
name: mental-models
description: Compatibility alias for using cross-disciplinary mental models to analyze a difficult decision, expose tensions, and synthesize recommendations.
---

# Mental Models Compatibility Entry

Read and follow `../../../skills/model-deliberation/SKILL.md` using Quick, Red team, or Decision log mode as appropriate.
