---
name: statistical-analysis
description: Compatibility alias for assumption-aware statistical testing, effect estimation, uncertainty reporting, diagnostics, and power analysis.
---

# Statistical Analysis Compatibility Entry

Read and follow `../../../skills/data-analysis/SKILL.md`.
