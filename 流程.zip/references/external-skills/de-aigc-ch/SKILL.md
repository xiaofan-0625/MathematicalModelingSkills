---
name: de-aigc-ch
description: Compatibility alias for naturalizing Chinese academic prose while protecting evidence, terminology, citations, and numerical consistency.
---

# Chinese AIGC Revision Compatibility Entry

Read and follow `../../../skills/academic-humanization/SKILL.md`.
