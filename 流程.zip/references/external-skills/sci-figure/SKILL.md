---
name: sci-figure
description: Compatibility alias for producing restrained SCI-style data figures with consistent typography, color, annotation, and high-resolution export.
---

# SCI Figure Compatibility Entry

Read and follow `../../../skills/scientific-visualization/SKILL.md`. Reuse retained templates and style assets in this directory when suitable.
