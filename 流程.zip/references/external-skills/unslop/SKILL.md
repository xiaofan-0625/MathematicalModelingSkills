---
name: unslop
description: Compatibility alias for audit-first reconstruction of formulaic AI-generated prose into natural, register-appropriate academic writing.
---

# Unslop Compatibility Entry

Read and follow `../../../skills/academic-humanization/SKILL.md`.
