---
name: rad-skills
description: Compatibility alias for routing research, analysis, and design subtasks through explicit specialist contracts.
---

# RAD Compatibility Entry

Read and follow `../../../skills/workflow-orchestration/SKILL.md`.
