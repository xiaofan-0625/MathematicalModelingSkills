---
name: humanizer
description: Compatibility alias for removing formulaic AI-writing patterns from English prose while preserving meaning, evidence, register, and author voice.
---

# Humanizer Compatibility Entry

Read and follow `../../../skills/academic-humanization/SKILL.md` using English pattern checks.
