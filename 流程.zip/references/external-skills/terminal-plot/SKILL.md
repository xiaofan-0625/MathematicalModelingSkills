---
name: terminal-plot
description: Compatibility alias for quick terminal-native charts used during data inspection when graphical rendering is unnecessary or unavailable.
---

# Terminal Plot Compatibility Entry

Read and follow `../../../skills/scientific-visualization/SKILL.md`, using terminal output only as an exploratory fallback.
