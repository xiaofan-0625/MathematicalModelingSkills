---
name: llm-council
description: Compatibility alias for comparing independent modeling viewpoints and synthesizing agreements, conflicts, evidence, and a final recommendation.
---

# LLM Council Compatibility Entry

Read and follow `../../../skills/model-deliberation/SKILL.md` using Council mode. Do not treat simulated opinions as evidence.
