---
name: plot-maxxing
description: Compatibility alias for strengthening the story, hierarchy, annotations, layout, and QA of a technically correct scientific chart.
---

# Plot Maxxing Compatibility Entry

Read and follow `../../../skills/scientific-visualization/SKILL.md`.
