---
name: de-aigc-skill
description: Compatibility alias for controlled Chinese academic humanization with length, terminology, LaTeX, citation, and consistency protection.
---

# AIGC-Down Compatibility Entry

Read and follow `../../../skills/academic-humanization/SKILL.md`.
