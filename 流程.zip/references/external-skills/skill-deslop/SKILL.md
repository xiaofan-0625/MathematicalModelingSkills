---
name: skill-deslop
description: Compatibility alias for removing filler, formulaic structures, stock AI phrases, and unnatural rhythm from academic prose without diluting content.
---

# Deslop Compatibility Entry

Read and follow `../../../skills/academic-humanization/SKILL.md`.
