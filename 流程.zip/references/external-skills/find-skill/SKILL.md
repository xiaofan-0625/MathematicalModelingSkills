---
name: find-skill
description: Compatibility alias for resolving a requested capability to a registered specialist Skill or documented fallback.
---

# Skill Resolution Compatibility Entry

Read and follow `../../../skills/workflow-orchestration/SKILL.md`, then resolve aliases through `../../../skills/registry.yaml`.
