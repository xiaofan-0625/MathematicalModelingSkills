---
name: naval-thinking
description: Compatibility alias for applying concise decision principles and long-horizon reasoning to a modeling or strategy choice.
---

# Decision Thinking Compatibility Entry

Read and follow `../../../skills/model-deliberation/SKILL.md`.
