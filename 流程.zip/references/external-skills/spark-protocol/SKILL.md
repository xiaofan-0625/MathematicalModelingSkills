---
name: spark-protocol
description: Compatibility alias for clarifying an under-specified task and turning it into a bounded, testable specialist assignment.
---

# Spark Protocol Compatibility Entry

Read and follow `../../../skills/workflow-orchestration/SKILL.md`.
