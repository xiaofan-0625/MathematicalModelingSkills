---
name: tufte-data-viz
description: Compatibility alias for low-clutter, comparison-centered, accessible data visualization using Tufte-inspired principles.
---

# Tufte Visualization Compatibility Entry

Read and follow `../../../skills/scientific-visualization/SKILL.md`.
