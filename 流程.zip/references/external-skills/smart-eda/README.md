# smart-eda

> Adaptive exploratory data analysis as a Claude Skill — profiles your data, picks the right techniques based on what's actually there, and produces a polished interactive dashboard plus a detailed analytical report.

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Claude Skill](https://img.shields.io/badge/Claude-Skill-orange)](https://support.claude.com/en/articles/12512180-use-skills-in-claude)

## What it is

A drop-in [Claude skill](https://support.claude.com/en/articles/12512180-use-skills-in-claude) that produces analyst-grade EDA from any tabular file (CSV, Excel, Parquet, TSV, JSON-lines). Unlike most "run describe() on everything" approaches, smart-eda **profiles the data first**, then chooses techniques based on actual column types, scale, and content — `int64` with 4 unique values is treated as categorical, `object` matching a date pattern is parsed as datetime, and so on.

The output is two complementary deliverables:
- **`dashboard.html`** — self-contained interactive Plotly dashboard (~5MB, works offline)
- **`eda_summary.md`** — detailed multi-section markdown report (300–400 lines for a typical dataset) with all the supporting numbers

Plus a separate reproducible Python script.

## What it catches that off-the-shelf tools miss

- **Mechanical leakage** — features with r > 0.95 to the target (e.g., `Sales = Cost + Gross_Profit`) get flagged before they ruin a model
- **Casing/whitespace inconsistency** — `pro` / `PRO` / `Pro` showing up as three categories instead of one
- **Future-dated values** — date offset bugs and parsing errors
- **Negative values where they shouldn't be** — `age = -1` in a row with otherwise valid data
- **High-cardinality categoricals** masquerading as IDs
- **Right-skew that needs a transform** before regression
- **Outlier proportions** worth investigating before averaging

## Demo

### Single file

![Single-file dashboard](docs/images/dashboard_demo.png)

```bash
python scripts/profile_data.py mydata.csv --output profile.json
python scripts/eda_runner.py mydata.csv --profile profile.json \
    --output-dir ./out --target Sales
```

Produces:
- `out/dashboard.html` — interactive dashboard (shown above as a screenshot — the real thing has hover tooltips, zoom, and a time-range slider)
- `out/eda_summary.md` — detailed report
- `out/*.png` — per-column plots

### Multi-file (relational data)

![Multi-file dashboard](docs/images/multifile_demo.png)

```bash
python scripts/multi_file_eda.py orders.csv customers.csv products.csv \
    --output-dir ./out --target sales
```

Auto-detects join keys, infers cardinality (1:1, 1:N, N:N), measures orphan rates, and runs the full EDA on the joined dataset. The schema diagram (top of dashboard) shows the fact table centered with arrows to dimension tables, labeled by cardinality.

## Features

### Adaptive type inference
- Numeric / categorical / datetime / text / id / boolean / constant — smarter than dtype
- `int64` with few unique values → categorical
- `object` matching date pattern → datetime
- Auto-detects target column by name regex

### Quality detection (10+ rules)
- Missing percentage with severity scaling
- Constant columns
- Casing and whitespace inconsistency
- Mixed-type columns
- Encoding artifacts (BOM, replacement chars)
- Suspicious negatives (e.g., negative `age`)
- Full-row duplicates
- High-cardinality warnings
- Future-dated values
- Encoding artifacts

### Interactive HTML dashboard
- 4 adaptive KPI cards
- Hero time-series chart with annotated peak/low and range slider
- Target distribution with skew note
- Correlation heatmap (Pearson, with adaptive cell-text contrast)
- Two top-categorical breakdowns (auto-selected by discriminating power)
- Quality-flags banner with severity-color dots
- Auto-generated insights: top findings, hypotheses, next steps
- Dark theme, polished typography, responsive layout

### Detailed markdown report
- Executive summary
- Full column inventory
- Per-column statistics (numeric: summary + extended percentiles p1/p5/p10/p25/p50/p75/p90/p95/p99; categorical: top values with counts; datetime/text/boolean/id/constant: typed treatment)
- Data quality assessment with each flag explained
- Correlation analysis (top pairs ranked + full matrix with leakage interpretation)
- Target variable analysis (predictor ranking, group-mean discrimination, top-5/bottom-5 extreme rows)
- **Temporal analysis** for time-series data (year-over-year with CAGR, month-of-year seasonality with indexed values, day-of-week pattern, trend slope and volatility)
- Top findings, hypotheses, next steps with supporting numbers
- Methodology section listing what was applied and what wasn't

### Multi-file EDA
- Profiles each file individually
- Detects join keys via name compatibility (exact match or singular/plural pairs) + type compatibility + ≥30% value overlap
- Infers cardinality (1:1, 1:N, N:1, N:N)
- Computes orphan rates on both sides of every join
- Auto-joins the strongest non-conflicting relationships starting from the fact table
- Renders a schema diagram (SVG) with arrows labeled by cardinality
- Runs the full single-file dashboard on the joined dataset

## Installation

### As a Claude skill (recommended for end users)

1. Download the latest release zip
2. In Claude.ai → Settings → Customize → Skills, click **+ Create skill**
3. Upload the zip
4. Toggle the skill on

Then ask Claude things like *"run EDA on this CSV"* with a file attached.

### As a standalone CLI tool

```bash
git clone https://github.com/k4thir/smart-eda.git
cd smart-eda
pip install -r requirements.txt

# Profile a dataset
python scripts/profile_data.py path/to/data.csv --output profile.json

# Run the full EDA
python scripts/eda_runner.py path/to/data.csv --profile profile.json \
    --output-dir ./out --target Sales
```

## Requirements

- Python 3.10+
- `pandas` ≥ 1.5
- `numpy` ≥ 1.23
- `matplotlib` ≥ 3.7
- `plotly` ≥ 5.0 (optional, for interactive dashboard)

See `requirements.txt`.

## Project structure

```
smart-eda/
├── SKILL.md                    # Skill definition + workflow guidance for Claude
├── ROADMAP.md                  # What's implemented + what's next
├── scripts/
│   ├── profile_data.py         # Adaptive type inference + quality flags
│   ├── eda_runner.py           # Single-file EDA: plots, dashboard, report
│   ├── dashboard_html.py       # Interactive Plotly dashboard
│   └── multi_file_eda.py       # Relational/multi-file EDA
└── references/
    ├── method_catalog.md       # Exhaustive method reference
    ├── statistical_tests.md    # Test selection guide
    ├── time_series.md          # TS-specific workflow
    ├── quality_issues.md       # Quality taxonomy
    ├── large_data.md           # Sampling and scale strategies
    └── visualization_guide.md  # Chart selection by data shape
```

## How it works

The skill follows a 7-phase workflow described in `SKILL.md`:

0. **Understand the ask** and locate the data (single file vs. multi-file)
1. **Load and profile** — `profile_data.py` infers semantic types and flags quality issues
1.5. **Multi-file analysis** (when applicable) — `multi_file_eda.py` detects relationships and joins
2. **Quality scan** — surfaces issues to address before deeper analysis
3. **Univariate analysis** — type-aware plots (histogram + boxplot for numeric, top-N bars for categorical, etc.)
4. **Relationship analysis** — correlation heatmap + target-relationship plots
5. **Specialized analyses** (time series, etc.) when applicable
6. **Synthesize insights** — top findings, hypotheses, next steps
7. **Deliverables** — interactive dashboard + detailed markdown report + reproducible script

See `SKILL.md` for the full description of each phase.

## Roadmap

See [ROADMAP.md](ROADMAP.md) for what's implemented and what's still missing. Highlights of what's *not yet* covered:

- PII / sensitive column detection (emails, phones, SSN patterns)
- Better type inference for booleans (`Y/N`, `T/F`) and geographic IDs (postal codes)
- Cross-column consistency rules (date ordering, sum constraints)
- Tier 3 deep dive: formal hypothesis tests with effect sizes, multivariate outliers, PCA, clustering
- Time-series specific: STL decomposition, ADF/KPSS, ACF/PACF (referenced but not auto-run)
- Sampling for >1M rows, Polars/DuckDB fallback
- Two-dataset comparison mode (drift detection)
- PDF and PowerPoint export

Contributions in any of these areas are very welcome — see [CONTRIBUTING.md](CONTRIBUTING.md).

## Contributing

Pull requests welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, code style, and how to add new heuristics or types.

## License

[MIT](LICENSE) — use it however you want, including commercially. No warranty.

## Acknowledgements

Built around John Tukey's 1977 framing of EDA as *"actively incisive, rather than passively descriptive, with real emphasis on the discovery of the unexpected."* The skill operationalizes that as: profile before analyzing, adapt to the data, surface insights — not just stats.

Inspired by and improving upon prior work in:
- [nimrodfisher/data-analytics-skills](https://github.com/nimrodfisher/data-analytics-skills) — Claude skill library with a `programmatic-eda` skill
- The official Anthropic [skills repository](https://github.com/anthropics/skills)
- KDnuggets EDA tutorials and the broader `pandas-profiling` / `ydata-profiling` ecosystem

---

*Built as a Claude skill. Works as a standalone Python tool.*
