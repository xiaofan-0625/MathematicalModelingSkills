---
name: smart-eda
description: Compatibility alias for adaptive exploratory data analysis, data-quality auditing, relationship discovery, and pre-modeling synthesis.
---

# Smart EDA Compatibility Entry

Read and follow `../../../skills/data-analysis/SKILL.md`.
