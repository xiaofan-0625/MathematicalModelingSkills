---
name: scipilot-figure
description: Compatibility alias for contract-first scientific figure planning, generation, technical inspection, visual QA, repair, and export.
---

# SciPilot Figure Compatibility Entry

Read and follow `../../../skills/scientific-visualization/SKILL.md`.
