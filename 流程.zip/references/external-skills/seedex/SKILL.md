---
name: seedex
description: Compatibility alias for structuring an exploratory task and routing it to a bounded specialist workflow.
---

# Seed Exploration Compatibility Entry

Read and follow `../../../skills/workflow-orchestration/SKILL.md`.
