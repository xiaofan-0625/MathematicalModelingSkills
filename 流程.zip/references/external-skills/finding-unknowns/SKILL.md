---
name: finding-unknowns
description: Compatibility alias for discovering missing information, blind spots, fragile assumptions, and unresolved modeling questions.
---

# Finding Unknowns Compatibility Entry

Read and follow `../../../skills/model-deliberation/SKILL.md` using Unknowns mode.
